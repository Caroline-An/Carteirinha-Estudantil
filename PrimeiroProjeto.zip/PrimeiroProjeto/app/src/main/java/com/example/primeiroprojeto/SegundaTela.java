package com.example.primeiroprojeto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SegundaTela extends AppCompatActivity {

    TextView nome;
    TextView instEns;
    TextView formacao;
    TextView area;
    TextView cpf;
    TextView rg;
    TextView nasc;
    TextView matr;
    TextView respSet;
    TextView formResp;

    Button botao2;

    Bundle parametros2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_segunda_tela);

        nome = (TextView)findViewById(R.id.nomeUser);
        instEns = (TextView) findViewById(R.id.instDeEns);
        formacao = (TextView) findViewById(R.id.formacaoAcademica);
        area = (TextView) findViewById(R.id.areaAtuacao);
        cpf = (TextView) findViewById(R.id.cpf1);
        rg = (TextView) findViewById(R.id.RG);
        nasc = (TextView) findViewById(R.id.dataNasci);
        matr = (TextView) findViewById(R.id.matriculaa);
        respSet = (TextView) findViewById(R.id.nomeRespo);
        formResp = (TextView) findViewById(R.id.areaRespo);

        Button botao2 = (Button) findViewById(R.id.botao2);

        //recuperando a intent enviada pela activity anterior
        Intent it = getIntent();

        if(it != null){
            Bundle parametros2 = it.getExtras();

            if (parametros2 != null){

                //recuperando os valores que foram passados na intent Tela2
                String strNome = parametros2.getString(("nome"));
                String strInstEns = parametros2.getString(("instiruicao"));
                String strForm = parametros2.getString(("formacao"));
                String strArea = parametros2.getString(("area"));
                String strCpf = parametros2.getString(("cpf"));
                String strRG = parametros2.getString(("rg"));
                String strNasc = parametros2.getString(("nascimento"));
                String strMatr = parametros2.getString(("matricula"));
                String strResp = parametros2.getString(("responsavel"));
                String strFormResp = parametros2.getString(("formacaoRespo"));

                //passando os valores recuperados para as views de Saída
                nome.setText(strNome.toString());
                instEns.setText(strInstEns.toString());
                formacao.setText(strForm.toString());
                area.setText(strArea.toString());
                cpf.setText(strCpf.toString());
                rg.setText(strRG.toString());
                nasc.setText(strNasc.toString());
                matr.setText(strMatr.toString());
                respSet.setText(strResp.toString());
                formResp.setText(strFormResp.toString());
            }
        }

        botao2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v){
                //elimina a activity
                finish();
            }
        });
    }
}
