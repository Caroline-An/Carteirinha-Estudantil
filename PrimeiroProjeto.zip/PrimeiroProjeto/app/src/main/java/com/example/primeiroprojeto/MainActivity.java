package com.example.primeiroprojeto;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nome;
    EditText instEns;
    EditText formacao;
    EditText area;
    EditText cpf;
    EditText rg;
    EditText nasc;
    EditText matr;
    EditText respSet;
    EditText formResp;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        nome = (EditText) findViewById(R.id.nome);
        instEns = (EditText) findViewById(R.id.instEns);
        formacao = (EditText) findViewById(R.id.formacao);
        area = (EditText) findViewById(R.id.area);
        cpf = (EditText) findViewById(R.id.cpf);
        rg = (EditText) findViewById(R.id.rg);
        nasc = (EditText) findViewById(R.id.nasc);
        matr = (EditText) findViewById(R.id.matr);
        respSet = (EditText) findViewById(R.id.respSet);
        formResp = (EditText) findViewById(R.id.formResp);

        Button botao1 = (Button) findViewById(R.id.botao1);

        botao1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent tela2 = new Intent(MainActivity.this, SegundaTela.class);

                //atribuindo valores através das chaves entre aspas
                Bundle parametros = new Bundle();       //pacote com infos

                parametros.putString("nome", nome.getText().toString());
                parametros.putString("instituicao", instEns.getText().toString());
                parametros.putString("formacao", formacao.getText().toString());
                parametros.putString("area", area.getText().toString());
                parametros.putString("cpf", cpf.getText().toString());
                parametros.putString("rg", rg.getText().toString());
                parametros.putString("nascimento", nasc.getText().toString());
                parametros.putString("matricula", matr.getText().toString());
                parametros.putString("responsavel", respSet.getText().toString());
                parametros.putString("formacaoRespo", formResp.getText().toString());

                //atribuindo as chaves/valores para a Segunda Tela
                tela2.putExtras(parametros);

                //inicializar a segunda activity
                startActivity(tela2);

            }
        });
    }

}